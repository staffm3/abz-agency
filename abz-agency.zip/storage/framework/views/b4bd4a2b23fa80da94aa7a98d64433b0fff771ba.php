<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="robots" content="noindex,nofollow">
    <title>404 Page not found</title>
    <style>
        html{color:#000;background:#FFF;}body,div,dl,dt,dd,ul,ol,li,h1,h2,h3,h4,h5,h6,pre,code,form,fieldset,legend,input,textarea,p,blockquote,th,td{margin:0;padding:0;}table{border-collapse:collapse;border-spacing:0;}fieldset,img{border:0;}address,caption,cite,code,dfn,em,strong,th,var{font-style:normal;font-weight:normal;}li{list-style:none;}caption,th{text-align:left;}h1,h2,h3,h4,h5,h6{font-size:100%;font-weight:normal;}q:before,q:after{content:'';}abbr,acronym{border:0;font-variant:normal;}sup{vertical-align:text-top;}sub{vertical-align:text-bottom;}input,textarea,select{font-family:inherit;font-size:inherit;font-weight:inherit;}input,textarea,select{*font-size:100%;}legend{color:#000;}
        html { background: #eee; padding: 10px }
        img { border: 0; }
        .sf-reset { width:970px; margin:0 auto; }
        .sf-reset { font: 11px Verdana, Arial, sans-serif; color: #333 }
        .sf-reset .clear { clear:both; height:0; font-size:0; line-height:0; }
        .sf-reset .clear_fix:after { display:block; height:0; clear:both; visibility:hidden; }
        .sf-reset .clear_fix { display:inline-block; }
        .sf-reset * html .clear_fix { height:1%; }
        .sf-reset .clear_fix { display:block; }
        .sf-reset, .sf-reset .block { margin: auto }
        .sf-reset abbr { border-bottom: 1px dotted #000; cursor: help; }
        .sf-reset p { font-size:14px; line-height:20px; color:#868686; padding-bottom:20px }
        .sf-reset strong { font-weight:bold; }
        .sf-reset a { color:#6c6159; cursor: default; }
        .sf-reset a img { border:none; }
        .sf-reset a:hover { text-decoration:underline; }
        .sf-reset em { font-style:italic; }
        .sf-reset h1, .sf-reset h2 { font: 20px Georgia, "Times New Roman", Times, serif }
        .sf-reset .exception_counter { background-color: #fff; color: #333; padding: 6px; float: left; margin-right: 10px; float: left; display: block; }
        .sf-reset .exception_title { margin-left: 3em; margin-bottom: 0.7em; display: block; }
        .sf-reset .exception_message { margin-left: 3em; display: block; }
        .sf-reset .traces li { font-size:12px; padding: 2px 4px; list-style-type:decimal; margin-left:20px; }
        .sf-reset .block { background-color:#FFFFFF; padding:10px 28px; margin-bottom:20px;
            -webkit-border-bottom-right-radius: 16px;
            -webkit-border-bottom-left-radius: 16px;
            -moz-border-radius-bottomright: 16px;
            -moz-border-radius-bottomleft: 16px;
            border-bottom-right-radius: 16px;
            border-bottom-left-radius: 16px;
            border-bottom:1px solid #ccc;
            border-right:1px solid #ccc;
            border-left:1px solid #ccc;
            word-wrap: break-word;
        }
        .sf-reset .block_exception { background-color:#ddd; color: #333; padding:20px;
            -webkit-border-top-left-radius: 16px;
            -webkit-border-top-right-radius: 16px;
            -moz-border-radius-topleft: 16px;
            -moz-border-radius-topright: 16px;
            border-top-left-radius: 16px;
            border-top-right-radius: 16px;
            border-top:1px solid #ccc;
            border-right:1px solid #ccc;
            border-left:1px solid #ccc;
            overflow: hidden;
            word-wrap: break-word;
        }
        .sf-reset a { background:none; color:#868686; text-decoration:none; }
        .sf-reset a:hover { background:none; color:#313131; text-decoration:underline; }
        .sf-reset ol { padding: 10px 0; }
        .sf-reset h1 { background-color:#FFFFFF; padding: 15px 28px; margin-bottom: 20px;
            -webkit-border-radius: 10px;
            -moz-border-radius: 10px;
            border-radius: 10px;
            border: 1px solid #ccc;
        }
        @media (max-width: 990px)
        {
            .sf-reset{
                width: 100%;
            }
        }
    </style>
</head>
<body>
<div class="sf-reset">
    <h1>Sorry, the page you are looking for could not be found.</h1>
</div>
</body>
</html>
<?php /**PATH D:\LaravelLessons\abz-agency\resources\views/errors/404.blade.php ENDPATH**/ ?>