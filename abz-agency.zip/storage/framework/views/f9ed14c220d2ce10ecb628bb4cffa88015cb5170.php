<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    "pages" => [
        "home" => "home",
        "users" => "users",
        "positions" => "positions",
        "create user" => "user.create"
    ]
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    "pages" => [
        "home" => "home",
        "users" => "users",
        "positions" => "positions",
        "create user" => "user.create"
    ]
]); ?>
<?php foreach (array_filter(([
    "pages" => [
        "home" => "home",
        "users" => "users",
        "positions" => "positions",
        "create user" => "user.create"
    ]
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<nav class="navbar navbar-dark navbar-expand-lg bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img src="<?php echo e(asset('img/icon.svg')); ?>" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                        <a class="nav-link
                        <?php if(url()->current() == route($route)): ?> active <?php endif; ?>
                        "
                        href="<?php echo e(route($route)); ?>">
                            <?php echo e(ucfirst($page)); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH D:\LaravelLessons\abz-agency\resources\views/components/navbar.blade.php ENDPATH**/ ?>