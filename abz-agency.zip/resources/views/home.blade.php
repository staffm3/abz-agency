<x-layout>
    <main class="text-center text-white">
        <h2>Made with ♥ for abz.agency :)</h2>
    </main>
</x-layout>
