<x-layout>
    <main class="d-flex flex-column gap-2">
        <div class="card-list d-flex justify-content-center align-items-center flex-wrap gap-5 p-5 w-100 overflow-y-scroll overflow-x-hidden">

        </div>
    </main>
    <script src="{{ asset('js/users.js') }}"></script>
</x-layout>
