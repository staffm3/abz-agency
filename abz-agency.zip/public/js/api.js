let mainBlock = document.querySelector(`main`);
let cardList = mainBlock.querySelector(`.card-list`);
